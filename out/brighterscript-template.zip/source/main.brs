sub main(args as dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)
    scene = screen.CreateScene("MainScene")
    if args <> invalid then
        scene.launchArgs = args
    end if
    screen.show()
    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then
                return
            end if
        else if msgType = "roInputEvent"
            info = msg.GetInfo()
            if info <> invalid then
                scene.launchArgs = info
            end if
        end if
    end while
end sub'//# sourceMappingURL=./main.bs.map